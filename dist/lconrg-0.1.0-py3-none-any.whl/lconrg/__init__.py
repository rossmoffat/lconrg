# src/lconrg/__init__.py
"""Levelised Cost of Energy calculator."""
__version__ = "0.2.0"
